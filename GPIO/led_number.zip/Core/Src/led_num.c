#include "led_num.h"

char led_number[10] = {
	0x3f,	//0
	0x06,	//1
	0x5b,	//2
	0x4f,	//3
	0x66,	//4
	0x6d,	//5
	0x7d,	//6
	0x07,	//7
	0x7f,	//8
	0x6f,	//9
};

char showNum(unsigned int i)
{
	if(i > 10)
		return 0xff;
	return led_number[i];
}

#ifndef LED_NUM_H
#define LED_NUM_H

char showNum(unsigned int i);

#endif
